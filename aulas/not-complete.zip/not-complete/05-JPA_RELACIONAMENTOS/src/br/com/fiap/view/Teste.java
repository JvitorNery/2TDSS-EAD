package br.com.fiap.view;

import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.persistence.EntityManager;

import br.com.fiap.dao.impl.GrupoAMDAOImpl;
import br.com.fiap.entity.GrupoAM;
import br.com.fiap.entity.ProjetoAM;
import br.com.fiap.singleton.EntityManagerFacotorySingleton;

public class Teste {
	public static void mains(String[] args){
		
		EntityManager em = EntityManagerFacotorySingleton.getInstance().createEntityManager();
		
		GrupoAM gAM = new GrupoAM(0,"grupoAM");
		ProjetoAM pAM = new ProjetoAM(0,"joao",new GregorianCalendar(1,Calendar.MAY,1997),8,"ok");
		GrupoAMDAOImpl tDAO = new GrupoAMDAOImpl(em);
		
	}
}
