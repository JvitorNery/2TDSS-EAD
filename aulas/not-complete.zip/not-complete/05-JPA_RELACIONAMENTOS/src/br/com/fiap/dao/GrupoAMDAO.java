package br.com.fiap.dao;

import br.com.fiap.entity.GrupoAM;
import br.com.fiap.entity.ProjetoAM;

public interface GrupoAMDAO extends GenericDAO<GrupoAM,Integer>{
	void insert(GrupoAM Pam);
	void update(GrupoAM Pam);
	void delete(int id);
	GrupoAM select(int id);
}
