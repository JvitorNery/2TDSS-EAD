package br.com.fiap.dao;

import br.com.fiap.entity.ProjetoAM;

public interface ProjetoAMDAO extends GenericDAO<ProjetoAM,Integer> {
	void insert(ProjetoAM Pam);
	void update(ProjetoAM Pam);
	void delete(int id);
	ProjetoAM select(int id);
}
