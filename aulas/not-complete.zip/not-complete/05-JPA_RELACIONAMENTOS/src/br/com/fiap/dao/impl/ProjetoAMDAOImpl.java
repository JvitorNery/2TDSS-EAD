package br.com.fiap.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.dao.ProjetoAMDAO;
import br.com.fiap.entity.ProjetoAM;
import br.com.fiap.exception.CommitException;
import br.com.fiap.exception.EntityNotFoundException;

public class ProjetoAMDAOImpl extends GenericDAOImpl<ProjetoAM,Integer> implements ProjetoAMDAO{
	
	EntityManager em;
	
	public ProjetoAMDAOImpl(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}


	@Override
	public void delete(Integer id) throws EntityNotFoundException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ProjetoAM findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save() throws CommitException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(ProjetoAM Pam) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(ProjetoAM Pam) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ProjetoAM select(int id) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
