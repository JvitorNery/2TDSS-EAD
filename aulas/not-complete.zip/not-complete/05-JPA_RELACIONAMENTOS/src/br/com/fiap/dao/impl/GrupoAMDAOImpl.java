package br.com.fiap.dao.impl;

import javax.persistence.EntityManager;

import br.com.fiap.dao.GrupoAMDAO;
import br.com.fiap.entity.GrupoAM;
import br.com.fiap.entity.ProjetoAM;
import br.com.fiap.exception.CommitException;
import br.com.fiap.exception.EntityNotFoundException;

public class GrupoAMDAOImpl extends GenericDAOImpl<GrupoAM,Integer> implements GrupoAMDAO {

	EntityManager em;
	
	public GrupoAMDAOImpl(EntityManager em) {
		super(em);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void delete(Integer id) throws EntityNotFoundException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public GrupoAM findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void save() throws CommitException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(GrupoAM Pam) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(GrupoAM Pam) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public GrupoAM select(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
