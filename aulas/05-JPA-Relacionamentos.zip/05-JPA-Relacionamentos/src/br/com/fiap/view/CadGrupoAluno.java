package br.com.fiap.view;

import java.util.GregorianCalendar;

import javax.persistence.EntityManager;

import br.com.fiap.dao.GrupoAmDAO;
import br.com.fiap.dao.ProjetoAmDAO;
import br.com.fiap.dao.impl.GrupoAmDAOImpl;
import br.com.fiap.dao.impl.ProjetoAmDAOImpl;
import br.com.fiap.entity.Aluno;
import br.com.fiap.entity.GrupoAm;
import br.com.fiap.entity.ProjetoAm;
import br.com.fiap.exception.CommitException;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class CadGrupoAluno {

	public static void main(String[] args) {
		
		
		GrupoAm g1 = new GrupoAm(0,"g1");
		ProjetoAm p1 = new ProjetoAm(0,"p1", GregorianCalendar.getInstance(), 8, "");
		
		g1.addAluno(new Aluno("joao"));
		g1.setProjeto(p1);
		
		EntityManager em = EntityManagerFactorySingleton
				.getInstance().createEntityManager();
		
		ProjetoAmDAO pAMDAO = new ProjetoAmDAOImpl(em);
		
		pAMDAO.insert(p1);
		
		try {
			//Commit
			pAMDAO.save();
			//Sucesso!
		} catch (CommitException e) {
			e.printStackTrace();
		}finally {
			em.close();
			System.exit(0); //Fecha o programa
		}
		
		GrupoAmDAO gAMDAO = new GrupoAmDAOImpl(em);
		
		gAMDAO.insert(g1);
		
		try {
			//Commit
			gAMDAO.save();
			//Sucesso!
		} catch (CommitException e) {
			e.printStackTrace();
		}finally {
			em.close();
			System.exit(0); //Fecha o programa
		}
		
		System.out.println("secess!");
		
	}

}
