package br.com.fiap.dao;

import br.com.fiap.entity.GrupoAm;

public interface GrupoAmDAO 
				extends GenericDAO<GrupoAm, Integer>{

}